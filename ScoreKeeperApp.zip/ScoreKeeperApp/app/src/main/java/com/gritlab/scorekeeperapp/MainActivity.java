package com.gritlab.scorekeeperapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int team1GoalScore;
    int team1FoulScore;
    int team1RedCardScore;
    int team1CornerScore;
    int team2GoalScore;
    int team2FoulScore;
    int team2RedCardScore;
    int team2CornerScore;

    String team1 = "Barcelona";
    String team2 = "Manchester City";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //I N C R E M E N T S

        //goals
        TextView team1Goal = findViewById(R.id.team1_goal);
        team1Goal.setOnClickListener(new View.OnClickListener() {

            final TextView team1GS = findViewById(R.id.team1_goal_score);

            @Override
            public void onClick(View view) {
                team1GoalScore++;
                team1GS.setText(String.valueOf(team1GoalScore));
            }
        });

        TextView team2Goal = findViewById(R.id.team2_goal);
        team2Goal.setOnClickListener(new View.OnClickListener() {

            final TextView team2GS = findViewById(R.id.team2_goal_score);

            @Override
            public void onClick(View view) {
                team2GoalScore++;
                team2GS.setText(String.valueOf(team2GoalScore));
            }
        });


        //corners
        TextView team1Corner = findViewById(R.id.team1_corner);
        team1Corner.setOnClickListener(new View.OnClickListener() {

            final TextView team1C = findViewById(R.id.team1_corner_score);

            @Override
            public void onClick(View view) {
                team1CornerScore++;
                team1C.setText(String.valueOf(team1CornerScore));
            }
        });

        TextView team2Corner = findViewById(R.id.team2_corner);
        team2Corner.setOnClickListener(new View.OnClickListener() {

            final TextView team2C = findViewById(R.id.team2_corner_score);

            @Override
            public void onClick(View view) {
                team2CornerScore++;
                team2C.setText(String.valueOf(team2CornerScore));
            }
        });


        //fouls

        final TextView team1Foul = findViewById(R.id.team1_foul);
        team1Foul.setOnClickListener(new View.OnClickListener() {

            final TextView team1F = findViewById(R.id.team1_foul_score);

            @Override
            public void onClick(View view) {
                team1FoulScore++;
                team1F.setText(String.valueOf(team1FoulScore));
            }
        });

        TextView team2Foul = findViewById(R.id.team2_foul);
        team2Foul.setOnClickListener(new View.OnClickListener() {

            final TextView team2F = findViewById(R.id.team2_foul_score);

            @Override
            public void onClick(View view) {
                team2FoulScore++;
                team2F.setText(String.valueOf(team2FoulScore));
            }
        });

        //Red Cards

        final TextView team1Reds = findViewById(R.id.team1_redcard);
        team1Reds.setOnClickListener(new View.OnClickListener() {

            final TextView team1R = findViewById(R.id.team1_redcard_score);

            @Override
            public void onClick(View view) {
                if (team1RedCardScore <= 2) {
                    team1RedCardScore++;
                    team1R.setText(String.valueOf(team1RedCardScore));
                } else
                    roughGame1();
            }
        });

        TextView team2Reds = findViewById(R.id.team2_redcard);
        team2Reds.setOnClickListener(new View.OnClickListener() {

            final TextView team2R = findViewById(R.id.team2_redcard_score);

            @Override
            public void onClick(View view) {
                if (team2RedCardScore <= 2) {
                    team2RedCardScore++;
                    team2R.setText(String.valueOf(team2RedCardScore));
                } else
                    roughGame2();
            }
        });
    }

    public void roughGame1() {
        Toast.makeText(this, "The Match is too rough. " + team2 + " WINS!", Toast.LENGTH_LONG).show();
        reset(null);
    }

    public void roughGame2() {
        Toast.makeText(this, "The Match is too rough. " + team1 + " WINS!", Toast.LENGTH_LONG).show();
        reset(null);
    }

    public void reset(View v) {
        team1GoalScore= 0;
        team1FoulScore= 0;
        team1CornerScore = 0;
        team1RedCardScore = 0;
        team2GoalScore= 0;
        team2FoulScore= 0;
        team2CornerScore = 0;
        team2RedCardScore = 0;

        TextView team1Goal = findViewById(R.id.team1_goal_score);
        team1Goal.setText(String.valueOf(team1GoalScore));

        TextView team2Goal = findViewById(R.id.team2_goal_score);
        team2Goal.setText(String.valueOf(team2GoalScore));

        TextView team1Foul = findViewById(R.id.team1_foul_score);
        team1Foul.setText(String.valueOf(team1FoulScore));

        TextView team2Foul = findViewById(R.id.team2_foul_score);
        team2Foul.setText(String.valueOf(team2FoulScore));

        TextView team1Reds = findViewById(R.id.team1_redcard_score);
        team1Reds.setText(String.valueOf(team1RedCardScore));

        TextView team2Reds = findViewById(R.id.team2_redcard_score);
        team2Reds.setText(String.valueOf(team2RedCardScore));

        TextView team1Corner = findViewById(R.id.team1_corner_score);
        team1Corner.setText(String.valueOf(team1CornerScore));

        TextView team2Corner = findViewById(R.id.team2_corner_score);
        team2Corner.setText(String.valueOf(team2CornerScore));
    }


}
